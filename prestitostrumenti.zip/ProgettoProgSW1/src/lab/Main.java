package lab;

import java.awt.EventQueue;

public class Main {
	public static void main(String[] args) {
		// la GUI va creata nel thread degli eventi di Swing
		EventQueue.invokeLater(() -> new FinestraLaboratorio().setVisible(true));
	}
}