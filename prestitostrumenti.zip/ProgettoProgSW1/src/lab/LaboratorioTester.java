package lab;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Classe tester, prova le funzionalita del laboratorio senza GUI
 */
 

public class LaboratorioTester {

	public static void main(String[] args) throws Exception {
		provaAssegnazioneEAttesa();
		provaInterruzione();
		provaSimulazione();
		provaSalvataggio();
	}

	private static Laboratorio creaLaboratorio() {
		ArrayList<Strumento> catalogo = new ArrayList<Strumento>();
		catalogo.add(new Strumento("OSC-01", "Oscilloscopio"));
		catalogo.add(new Strumento("MUL-01", "Multimetro"));
		catalogo.add(new Strumento("MUL-02", "Multimetro"));
		catalogo.add(new Strumento("GEN-01", "Generatore"));
		return new Laboratorio(catalogo, new ArrayList<String>());
	}

	// un solo oscilloscopio: la seconda richiesta deve attendere la restituzione
	private static void provaAssegnazioneEAttesa() throws InterruptedException {
		System.out.println("--- Assegnazione e attesa ---");
		Laboratorio lab = creaLaboratorio();
		Strumento s = lab.richiedi("Anna", "Oscilloscopio");
		System.out.println("Anna ha " + s.getId() + ", disponibili: " + lab.numeroDisponibili() + " (atteso 3)");

		Utente luca = new Utente("Luca", lab, tipoOscilloscopio(), 1, 10);
		Thread t = new Thread(luca);
		t.start();
		Thread.sleep(300); // diamo tempo a Luca di mettersi in attesa
		System.out.println("In attesa: " + lab.numeroInAttesa() + " (atteso 1)");

		lab.restituisci("Anna", s);
		t.join();
		System.out.println("Dopo la restituzione Luca ha finito, in attesa: " + lab.numeroInAttesa() + " (atteso 0)");
		stampaStorico(lab);
	}

	// un thread interrotto mentre attende deve lasciare lo stato coerente
	private static void provaInterruzione() throws InterruptedException {
		System.out.println("--- Interruzione di un thread in attesa ---");
		Laboratorio lab = creaLaboratorio();
		Strumento s = lab.richiedi("Anna", "Oscilloscopio");

		Thread t = new Thread(new Utente("Luca", lab, tipoOscilloscopio(), 1, 10));
		t.start();
		Thread.sleep(300);
		t.interrupt();
		t.join();
		System.out.println("In attesa: " + lab.numeroInAttesa() + " (atteso 0)");
		System.out.println("In prestito: " + lab.numeroInPrestito() + " (atteso 1)");
		lab.restituisci("Anna", s);
		System.out.println("Disponibili: " + lab.numeroDisponibili() + " (atteso 4)");
	}

	// 6 utenti (thread) e 4 strumenti: alla fine tutto deve essere restituito
	private static void provaSimulazione() throws InterruptedException {
		System.out.println("--- Simulazione con 6 utenti e 4 strumenti ---");
		Laboratorio lab = creaLaboratorio();
		ArrayList<Thread> thread = new ArrayList<Thread>();
		for (int i = 1; i <= 6; i++) {
			Thread t = new Thread(new Utente("Utente" + i, lab, lab.tipi(), 3, 100));
			thread.add(t);
			t.start();
		}
		for (Thread t : thread) {
			t.join();
		}
		System.out.println("Disponibili: " + lab.numeroDisponibili() + " (atteso 4)");
		System.out.println("In attesa: " + lab.numeroInAttesa() + " (atteso 0)");
		stampaStorico(lab);
	}

	// salva su file, ricarica e confronta
	private static void provaSalvataggio() throws IOException, InterruptedException {
		System.out.println("--- Salvataggio e caricamento ---");
		Laboratorio lab = creaLaboratorio();
		Strumento s = lab.richiedi("Anna", "Generatore");
		lab.restituisci("Anna", s);

		Persistenza.salva("prova_tester.txt", lab);
		Laboratorio caricato = Persistenza.carica("prova_tester.txt");
		System.out.println("Catalogo uguale: " + lab.righeCatalogo().equals(caricato.righeCatalogo()) + " (atteso true)");
		System.out.println("Storico uguale: " + lab.copiaStorico().equals(caricato.copiaStorico()) + " (atteso true)");
		new java.io.File("prova_tester.txt").delete();
	}

	private static ArrayList<String> tipoOscilloscopio() {
		ArrayList<String> tipi = new ArrayList<String>();
		tipi.add("Oscilloscopio");
		return tipi;
	}

	private static void stampaStorico(Laboratorio lab) {
		for (String evento : lab.copiaStorico()) {
			System.out.println("  " + evento);
		}
	}
}
