package lab;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * Salva e carica su file di testo catalogo e storico. Una riga per elemento:
 *   STRUMENTO;id;tipo
 *   EVENTO;testo dell'evento
 * Lo stato "in prestito" non si salva: al caricamento gli strumenti sono tutti disponibili.
 */
public class Persistenza {

	public static void salva(String nomeFile, Laboratorio lab) throws IOException {
		ArrayList<String> catalogo = lab.righeCatalogo();
		ArrayList<String> storico = lab.copiaStorico();
		PrintWriter out = new PrintWriter(nomeFile);
		for (String riga : catalogo) {
			out.println("STRUMENTO;" + riga);
		}
		for (String evento : storico) {
			out.println("EVENTO;" + evento);
		}
		out.close();
	}

	public static Laboratorio carica(String nomeFile) throws IOException {
		ArrayList<Strumento> catalogo = new ArrayList<Strumento>();
		ArrayList<String> storico = new ArrayList<String>();
		BufferedReader in = new BufferedReader(new FileReader(nomeFile));
		String riga = in.readLine();
		while (riga != null) {
			String[] campi = riga.split(";", 3);
			if (campi[0].equals("STRUMENTO")) {
				catalogo.add(new Strumento(campi[1], campi[2]));
			} else if (campi[0].equals("EVENTO")) {
				storico.add(campi[1] + (campi.length > 2 ? ";" + campi[2] : ""));
			}
			riga = in.readLine();
		}
		in.close();
		return new Laboratorio(catalogo, storico);
	}
}
