package lab; // Dichiara il pacchetto di appartenenza della classe

import java.time.LocalTime; // Importa la classe LocalTime per ottenere l'ora corrente senza la data
import java.util.ArrayList; // Importa la classe ArrayList per gestire liste dinamiche di oggetti

/**
 * Oggetto monitor: contiene lo stato condiviso (strumenti, richieste in attesa, storico)
 * e tutti i metodi che lo usano sono synchronized.
 * Dentro il monitor non si usano file, sleep o la GUI.
 */
public class Laboratorio { 
	private ArrayList<Strumento> strumenti; 
	private ArrayList<String> inAttesa; 
	private ArrayList<String> storico; 

	public Laboratorio(ArrayList<Strumento> strumenti, ArrayList<String> storico) { 
		this.strumenti = strumenti; 
		this.storico = storico; 
		this.inAttesa = new ArrayList<String>(); 
	} 

	// cerca uno strumento libero del tipo richiesto (null se non c'e')
	private Strumento cercaLibero(String tipo) { 
		for (Strumento s : strumenti) { 
			if (s.getTipo().equals(tipo) && !s.isInPrestito()) { 
				return s; 
			} 
		} 
		return null; 
	} 

	// Metodo privato per aggiungere un evento allo storico registrando l'ora
	private void registra(String evento) { 
		storico.add(LocalTime.now().withNano(0) + " " + evento); 
	} 

	// controllo e assegnazione sono un'unica operazione protetta
	public synchronized Strumento richiedi(String utente, String tipo) throws InterruptedException { 
		Strumento s = cercaLibero(tipo); 
		if (s == null) { 
			String richiesta = utente + " - " + tipo; 
			inAttesa.add(richiesta); 
			registra(utente + " in attesa di " + tipo); 
			try { 
				while (s == null) { 
					wait(); // Mette il thread in attesa del rilascio di uno strumento
					s = cercaLibero(tipo); // Una volta svegliato, riprova a cercare lo strumento libero
				} 
			} catch (InterruptedException e) { 
				registra(utente + " annulla l'attesa di " + tipo); 
				throw e; 
			} finally { 
				inAttesa.remove(richiesta); 
			} 
		} 
		s.setInPrestito(true); 
		registra(utente + " ottiene " + s.getId()); 
		return s; 
	} 

	public synchronized void restituisci(String utente, Strumento s) { 
		s.setInPrestito(false); 
		registra(utente + " restituisce " + s.getId()); 
		notifyAll(); 
	} 



	public synchronized ArrayList<String> descriviStrumenti() { 
		ArrayList<String> righe = new ArrayList<String>(); 
		for (Strumento s : strumenti) { 
			righe.add(s.toString()); 
		} 
		return righe; 
	} 

	
	// Metodo sincronizzato che filtra e restituisce solo gli strumenti liberi
	public synchronized ArrayList<String> descriviDisponibili() { 
		ArrayList<String> righe = new ArrayList<String>(); 
		for (Strumento s : strumenti) { 
			if (!s.isInPrestito()) { 
				righe.add(s.toString()); 
			} 
		} 
		return righe; 
	} 

	
	// Metodo sincronizzato che filtra e restituisce solo gli strumenti in uso
	public synchronized ArrayList<String> descriviInPrestito() { 
		ArrayList<String> righe = new ArrayList<String>(); 
		for (Strumento s : strumenti) { 
			if (s.isInPrestito()) { 
				righe.add(s.toString()); 
			} 
		} 
		return righe; 
	} 

	// Metodo sincronizzato che restituisce la lista delle richieste in attesa
	public synchronized ArrayList<String> richiesteInAttesa() { 
		return new ArrayList<String>(inAttesa); 
	} 

	// Metodo sincronizzato che restituisce la lista dello storico
	public synchronized ArrayList<String> copiaStorico() { 
		return new ArrayList<String>(storico); 
	} 

	// Metodo sincronizzato per formattare il catalogo ai fini del salvataggio su file
	public synchronized ArrayList<String> righeCatalogo() { 
		ArrayList<String> righe = new ArrayList<String>(); 
		for (Strumento s : strumenti) { 
			righe.add(s.getId() + ";" + s.getTipo()); 
		} 
		return righe; 
		} 

	
	// Metodo sincronizzato per estrarre l'elenco dei tipi distinti di strumenti
	public synchronized ArrayList<String> tipi() { 
		ArrayList<String> tipi = new ArrayList<String>(); 
		for (Strumento s : strumenti) {
			if (!tipi.contains(s.getTipo())) { 
				tipi.add(s.getTipo()); 
			} 
		} 
		return tipi; 
	} 

	
	//Metodo sincronizzato che conta quanti strumenti sono in prestito
	public synchronized int numeroInPrestito() { // 
		int n = 0; 
		for (Strumento s : strumenti) { 
			if (s.isInPrestito()) { 
				n++; 
			} 
		} 
		return n; 
	} 

	
	// Metodo sincronizzato che calcola quanti strumenti sono disponibili
	public synchronized int numeroDisponibili() { 
		return strumenti.size() - numeroInPrestito(); 
	} 

	
	// Metodo sincronizzato che restituisce il numero di utenti/richieste in attesa
	public synchronized int numeroInAttesa() { 
		return inAttesa.size(); 
	} 
} 



















