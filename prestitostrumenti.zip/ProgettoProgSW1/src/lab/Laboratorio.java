package lab; // Dichiara il pacchetto di appartenenza della classe

import java.time.LocalTime; // Importa la classe LocalTime per ottenere l'ora corrente senza la data
import java.util.ArrayList; // Importa la classe ArrayList per gestire liste dinamiche di oggetti

/**
 * Oggetto monitor: contiene lo stato condiviso (strumenti, richieste in attesa, storico)
 * e tutti i metodi che lo usano sono synchronized.
 * Dentro il monitor non si usano file, sleep o la GUI.
 */
public class Laboratorio { // Dichiara la classe Laboratorio che agisce da Monitor per la simulazione
	private ArrayList<Strumento> strumenti; // Dichiara la lista di tutti gli strumenti del laboratorio
	private ArrayList<String> inAttesa; // Dichiara la lista delle richieste attualmente in attesa
	private ArrayList<String> storico; // Dichiara la lista dello storico di tutti gli eventi avvenuti

	public Laboratorio(ArrayList<Strumento> strumenti, ArrayList<String> storico) { // Costruttore della classe Laboratorio
		this.strumenti = strumenti; // Assegna la lista di strumenti passata come parametro all'attributo di istanza
		this.storico = storico; // Assegna la lista dello storico passata come parametro all'attributo di istanza
		this.inAttesa = new ArrayList<String>(); // Inizializza la lista delle attese come nuova lista vuota
	} // Chiude il costruttore

	// cerca uno strumento libero del tipo richiesto (null se non c'e')
	private Strumento cercaLibero(String tipo) { // Metodo privato per trovare il primo strumento libero del tipo specificato
		for (Strumento s : strumenti) { // Scorre ciascun strumento presente nel catalogo
			if (s.getTipo().equals(tipo) && !s.isInPrestito()) { // Controlla se il tipo coincide e se lo strumento NON è in prestito
				return s; // Restituisce lo strumento libero trovato
			} // Chiude l'istruzione if
		} // Chiude il ciclo for
		return null; // Restituisce null se non è stato trovato alcun strumento libero di quel tipo
	} // Chiude il metodo cercaLibero

	private void registra(String evento) { // Metodo privato per aggiungere un evento allo storico registrando l'ora
		storico.add(LocalTime.now().withNano(0) + " " + evento); // Aggiunge allo storico l'ora attuale (senza nanosecondi) e il testo dell'evento
	} // Chiude il metodo registra

	// controllo e assegnazione sono un'unica operazione protetta
	public synchronized Strumento richiedi(String utente, String tipo) throws InterruptedException { // Metodo sincronizzato per richiedere uno strumento
		Strumento s = cercaLibero(tipo); // Tenta di cercare uno strumento disponibile del tipo richiesto
		if (s == null) { // Se non c'è alcun strumento libero disponibile
			String richiesta = utente + " - " + tipo; // Crea la stringa rappresentativa della richiesta in attesa
			inAttesa.add(richiesta); // Aggiunge la richiesta alla lista di quelle in attesa
			registra(utente + " in attesa di " + tipo); // Registra nello storico che l'utente è entrato in attesa
			try { // Apre il blocco try per gestire l'interruzione del thread durante l'attesa
				while (s == null) { // Ciclo while per ricontrollare la disponibilità al risveglio (previene risvegli spuri)
					wait(); // Mette il thread in attesa del rilascio di uno strumento
					s = cercaLibero(tipo); // Una volta svegliato, riprova a cercare lo strumento libero
				} // Chiude il ciclo while
			} catch (InterruptedException e) { // Gestisce l'interruzione del thread durante il wait
				registra(utente + " annulla l'attesa di " + tipo); // Registra l'annullamento dell'attesa nello storico
				throw e; // Rilancia l'eccezione per notificare il chiamante
			} finally { // Blocco eseguito sempre, sia in caso di successo che di eccezione
				inAttesa.remove(richiesta); // Rimuove la richiesta dalla lista delle attese
			} // Chiude il blocco finally
		} // Chiude la condizione if
		s.setInPrestito(true); // Imposta lo stato dello strumento come "in prestito"
		registra(utente + " ottiene " + s.getId()); // Registra nello storico che l'utente ha ottenuto lo strumento
		return s; // Restituisce lo strumento assegnato all'utente
	} // Chiude il metodo richiedi

	public synchronized void restituisci(String utente, Strumento s) { // Metodo sincronizzato per restituire uno strumento
		s.setInPrestito(false); // Imposta lo stato dello strumento come "non in prestito" (libero)
		registra(utente + " restituisce " + s.getId()); // Registra la restituzione dello strumento nello storico
		notifyAll(); // Risveglia tutti i thread in attesa sul monitor affinché riprovino a prendere uno strumento
	} // Chiude il metodo restituisci

	// i metodi seguenti restituiscono copie, cosi' chi li chiama non tocca lo stato

	public synchronized ArrayList<String> descriviStrumenti() { // Metodo sincronizzato che restituisce la descrizione di tutti gli strumenti
		ArrayList<String> righe = new ArrayList<String>(); // Crea una nuova lista per contenere le descrizioni
		for (Strumento s : strumenti) { // Scorre tutti gli strumenti presenti
			righe.add(s.toString()); // Aggiunge la rappresentazione in testo dello strumento alla lista
		} // Chiude il ciclo for
		return righe; // Restituisce la lista con le descrizioni di tutti gli strumenti
	} // Chiude il metodo descriviStrumenti

	// *** MODIFICA: Nuovo metodo per recuperare solo gli strumenti DISPONIBILI (Colonna Sinistra) ***
	public synchronized ArrayList<String> descriviDisponibili() { // Metodo sincronizzato che filtra e restituisce solo gli strumenti liberi
		ArrayList<String> righe = new ArrayList<String>(); // Crea una nuova lista vuota per le descrizioni degli strumenti liberi
		for (Strumento s : strumenti) { // Scorre ciascun strumento del catalogo
			if (!s.isInPrestito()) { // Se lo strumento NON è attualmente in prestito
				righe.add(s.toString()); // Aggiunge la descrizione dello strumento libero alla lista
			} // Chiude l'istruzione if
		} // Chiude il ciclo for
		return righe; // Restituisce la lista degli strumenti disponibili
	} // Chiude il metodo descriviDisponibili

	// *** MODIFICA: Nuovo metodo per recuperare solo gli strumenti IN PRESTITO (Colonna Centrale) ***
	public synchronized ArrayList<String> descriviInPrestito() { // Metodo sincronizzato che filtra e restituisce solo gli strumenti in uso
		ArrayList<String> righe = new ArrayList<String>(); // Crea una nuova lista vuota per le descrizioni degli strumenti in uso
		for (Strumento s : strumenti) { // Scorre ciascun strumento del catalogo
			if (s.isInPrestito()) { // Se lo strumento è attualmente in prestito
				righe.add(s.toString()); // Aggiunge la descrizione dello strumento in prestito alla lista
			} // Chiude l'istruzione if
		} // Chiude il ciclo for
		return righe; // Restituisce la lista degli strumenti in prestito
	} // Chiude il metodo descriviInPrestito

	public synchronized ArrayList<String> richiesteInAttesa() { // Metodo sincronizzato che restituisce la lista delle richieste in attesa
		return new ArrayList<String>(inAttesa); // Restituisce una copia difensiva della lista inAttesa
	} // Chiude il metodo richiesteInAttesa

	public synchronized ArrayList<String> copiaStorico() { // Metodo sincronizzato che restituisce la lista dello storico
		return new ArrayList<String>(storico); // Restituisce una copia difensiva della lista storico
	} // Chiude il metodo copiaStorico

	// una riga "id;tipo" per ogni strumento, serve per il salvataggio
	public synchronized ArrayList<String> righeCatalogo() { // Metodo sincronizzato per formattare il catalogo ai fini del salvataggio su file
		ArrayList<String> righe = new ArrayList<String>(); // Crea una nuova lista per contenere le righe formattate
		for (Strumento s : strumenti) { // Scorre tutti gli strumenti
			righe.add(s.getId() + ";" + s.getTipo()); // Formatta la riga come "ID;Tipo" e la aggiunge alla lista
		} // Chiude il ciclo for
		return righe; // Restituisce la lista delle righe formattate
	} // Chiude il metodo righeCatalogo

	// i tipi di strumento presenti, senza ripetizioni
	public synchronized ArrayList<String> tipi() { // Metodo sincronizzato per estrarre l'elenco dei tipi distinti di strumenti
		ArrayList<String> tipi = new ArrayList<String>(); // Crea una nuova lista vuota per memorizzare i tipi unici
		for (Strumento s : strumenti) { // Scorre tutti gli strumenti del laboratorio
			if (!tipi.contains(s.getTipo())) { // Se il tipo dello strumento non è ancora presente nella lista
				tipi.add(s.getTipo()); // Aggiunge il nuovo tipo alla lista
			} // Chiude la condizione if
		} // Chiude il ciclo for
		return tipi; // Restituisce la lista dei tipi univoci di strumenti
	} // Chiude il metodo tipi

	public synchronized int numeroInPrestito() { // Metodo sincronizzato che conta quanti strumenti sono in prestito
		int n = 0; // Inizializza il contatore a zero
		for (Strumento s : strumenti) { // Scorre tutti gli strumenti
			if (s.isInPrestito()) { // Se lo strumento è in prestito
				n++; // Incrementa il contatore di 1
			} // Chiude la condizione if
		} // Chiude il ciclo for
		return n; // Restituisce il conteggio totale degli strumenti in prestito
	} // Chiude il metodo numeroInPrestito

	public synchronized int numeroDisponibili() { // Metodo sincronizzato che calcola quanti strumenti sono disponibili
		return strumenti.size() - numeroInPrestito(); // Restituisce la differenza tra il totale degli strumenti e quelli in prestito
	} // Chiude il metodo numeroDisponibili

	public synchronized int numeroInAttesa() { // Metodo sincronizzato che restituisce il numero di utenti/richieste in attesa
		return inAttesa.size(); // Restituisce la dimensione attuale della lista inAttesa
	} // Chiude il metodo numeroInAttesa
} // Chiude la classe Laboratorio







































/*package lab;

import java.time.LocalTime;
import java.util.ArrayList;

/**
 * Oggetto monitor: contiene lo stato condiviso (strumenti, richieste in attesa, storico)
 * e tutti i metodi che lo usano sono synchronized.
 *  Dentro il monitor non si usano file, sleep o la GUI.
 */
/*public class Laboratorio {
	private ArrayList<Strumento> strumenti;
	private ArrayList<String> inAttesa;
	private ArrayList<String> storico;

	public Laboratorio(ArrayList<Strumento> strumenti, ArrayList<String> storico) {
		this.strumenti = strumenti;
		this.storico = storico;
		this.inAttesa = new ArrayList<String>();
	}

	// cerca uno strumento libero del tipo richiesto (null se non c'e')
	private Strumento cercaLibero(String tipo) {
		for (Strumento s : strumenti) {
			if (s.getTipo().equals(tipo) && !s.isInPrestito()) {
				return s;
			}
		}
		return null;
	}

	private void registra(String evento) {
		storico.add(LocalTime.now().withNano(0) + " " + evento);
	}

	// controllo e assegnazione sono un'unica operazione protetta
	public synchronized Strumento richiedi(String utente, String tipo) throws InterruptedException {
		Strumento s = cercaLibero(tipo);
		if (s == null) {
			String richiesta = utente + " - " + tipo;
			inAttesa.add(richiesta);
			registra(utente + " in attesa di " + tipo);
			try {
				while (s == null) { // al risveglio ricontrollo la condizione
					wait();
					s = cercaLibero(tipo);
				}
			} catch (InterruptedException e) {
				registra(utente + " annulla l'attesa di " + tipo);
				throw e;
			} finally {
				inAttesa.remove(richiesta); // se interrotto, la richiesta viene comunque tolta
			}
		}
		s.setInPrestito(true);
		registra(utente + " ottiene " + s.getId());
		return s;
	}

	public synchronized void restituisci(String utente, Strumento s) {
		s.setInPrestito(false);
		registra(utente + " restituisce " + s.getId());
		notifyAll(); // sveglia chi e' in attesa
	}

	// i metodi seguenti restituiscono copie, cosi' chi li chiama non tocca lo stato

	public synchronized ArrayList<String> descriviStrumenti() {
		ArrayList<String> righe = new ArrayList<String>();
		for (Strumento s : strumenti) {
			righe.add(s.toString());
		}
		return righe;
	}

	public synchronized ArrayList<String> richiesteInAttesa() {
		return new ArrayList<String>(inAttesa);
	}

	public synchronized ArrayList<String> copiaStorico() {
		return new ArrayList<String>(storico);
	}

	// una riga "id;tipo" per ogni strumento, serve per il salvataggio
	public synchronized ArrayList<String> righeCatalogo() {
		ArrayList<String> righe = new ArrayList<String>();
		for (Strumento s : strumenti) {
			righe.add(s.getId() + ";" + s.getTipo());
		}
		return righe;
	}

	// i tipi di strumento presenti, senza ripetizioni
	public synchronized ArrayList<String> tipi() {
		ArrayList<String> tipi = new ArrayList<String>();
		for (Strumento s : strumenti) {
			if (!tipi.contains(s.getTipo())) {
				tipi.add(s.getTipo());
			}
		}
		return tipi;
	}

	public synchronized int numeroInPrestito() {
		int n = 0;
		for (Strumento s : strumenti) {
			if (s.isInPrestito()) {
				n++;
			}
		}
		return n;
	}

	public synchronized int numeroDisponibili() {
		return strumenti.size() - numeroInPrestito();
	}

	public synchronized int numeroInAttesa() {
		return inAttesa.size();
	}
}*/
