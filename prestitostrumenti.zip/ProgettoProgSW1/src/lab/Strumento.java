package lab;





public class Strumento {
	private String id;
	private String tipo;
	private boolean inPrestito;

	public Strumento(String id, String tipo) {
		this.id = id;
		this.tipo = tipo;
		this.inPrestito = false;
	}

	public String getId() {
		return id;
	}

	public String getTipo() {
		return tipo;
	}

	public boolean isInPrestito() {
		return inPrestito;
	}

	public void setInPrestito(boolean inPrestito) {
		this.inPrestito = inPrestito;
	}

	public String toString() {
		if (inPrestito) {
			return id + " - " + tipo + " - In prestito";
		}
		return id + " - " + tipo + " - Disponibile";
	}
}
