package lab;

import java.util.ArrayList;
import java.util.Random;

/**
 * Un utente simulato, eseguito da un thread. Ripete: richiede uno strumento,
 * lo tiene per un po' (sleep = durata del prestito) e lo restituisce.
 */
public class Utente implements Runnable {
	private String nome;
	private Laboratorio lab;
	private ArrayList<String> tipi;
	private int numeroPrestiti;
	private int durataMassima;
	private Random random = new Random();

	public Utente(String nome, Laboratorio lab, ArrayList<String> tipi, int numeroPrestiti, int durataMassima) {
		this.nome = nome;
		this.lab = lab;
		this.tipi = tipi;
		this.numeroPrestiti = numeroPrestiti;
		this.durataMassima = durataMassima;
	}

	public void run() {
		try {
			for (int i = 0; i < numeroPrestiti; i++) {
				String tipo = tipi.get(random.nextInt(tipi.size()));
				Strumento s = lab.richiedi(nome, tipo);
				try {
					Thread.sleep(50 + random.nextInt(durataMassima));
				} finally {
					lab.restituisci(nome, s); // lo strumento torna sempre, anche se interrotti
				}
			}
		} catch (InterruptedException e) {
			// simulazione interrotta: il thread termina
		}
	}
}
