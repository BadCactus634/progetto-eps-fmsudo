package lab;

import java.util.ArrayList;
import java.util.Random;


public class Utente implements Runnable {
	private static final int MIN_MILLISEC_STOP = 50;
	private String nome;
	private Laboratorio lab;
	private ArrayList<String> tipi;
	private int numeroPrestiti;
	private int durataMassima;
	private Random random = new Random();

	public Utente(String nome, Laboratorio lab, ArrayList<String> tipi, int numeroPrestiti, int durataMassima) {
		this.nome = nome;
		this.lab = lab;
		this.tipi = tipi;
		this.numeroPrestiti = numeroPrestiti;
		this.durataMassima = durataMassima;
	}

	public void run() {
		try {
			for (int i = 0; i < numeroPrestiti; i++) {
				String tipo = tipi.get(random.nextInt(tipi.size()));
				Strumento s = lab.richiedi(nome, tipo);
				try {
					Thread.sleep(MIN_MILLISEC_STOP + random.nextInt(durataMassima));
				} finally {
					lab.restituisci(nome, s); // lo strumento torna sempre, anche se interrotti
				}
			}
		} catch (InterruptedException e) {
			// simulazione interrotta: il thread termina
		}
	}
}
