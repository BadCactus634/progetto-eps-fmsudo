
package lab;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public class FinestraLaboratorio extends JFrame {
	private static final String FILE = "laboratorio.txt";

	private Laboratorio lab;
	private ArrayList<Thread> threadUtenti = new ArrayList<Thread>();
	private boolean inCorso = false;
	private boolean storicoDaAggiornare = true; 

	private JLabel etDisponibili = new JLabel("Disponibili: 0");
	private JLabel etInPrestito = new JLabel("In prestito: 0");
	private JLabel etInAttesa = new JLabel("In attesa: 0");
    
    // *** MODIFICA: Ho diviso l'area degli strumenti in due aree distinte ***
	private JTextArea areaDisponibili = new JTextArea(10, 20); 
	private JTextArea areaInPrestito = new JTextArea(10, 20); 
	private JTextArea areaAttese = new JTextArea(10, 20); 
	private JTextArea areaStorico = new JTextArea(8, 60); 

	private JTextField campoUtenti = new JTextField("6", 4);
	private JTextField campoPrestiti = new JTextField("3", 4);
	private JTextField campoDurata = new JTextField("1000", 5);

	private JButton bAvvia = new JButton("Avvia simulazione");
	private JButton bInterrompi = new JButton("Interrompi");
	private JButton bSalva = new JButton("Salva dati");
	private JButton bCarica = new JButton("Carica dati");

	public FinestraLaboratorio() {
		super("Prestito strumenti");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		caricaAllAvvio();

		areaDisponibili.setEditable(false); 
		areaInPrestito.setEditable(false); 
		areaAttese.setEditable(false); 
		areaStorico.setEditable(false);

		
        // Colonna 1: Disponibili (Etichetta + Area testo)
		JPanel colDisponibili = new JPanel(new BorderLayout());
		colDisponibili.add(etDisponibili, BorderLayout.NORTH);
		colDisponibili.add(new JScrollPane(areaDisponibili), BorderLayout.CENTER);

        // Colonna 2: In Prestito (Etichetta + Area testo)
		JPanel colInPrestito = new JPanel(new BorderLayout());
		colInPrestito.add(etInPrestito, BorderLayout.NORTH);
		colInPrestito.add(new JScrollPane(areaInPrestito), BorderLayout.CENTER);

        // Colonna 3: In Attesa (Etichetta + Area testo)
		JPanel colAttesa = new JPanel(new BorderLayout());
		colAttesa.add(etInAttesa, BorderLayout.NORTH);
		colAttesa.add(new JScrollPane(areaAttese), BorderLayout.CENTER);

        // Pannello centrale che raggruppa le 3 colonne
		JPanel centroColonne = new JPanel(new GridLayout(1, 3, 10, 0)); 
		centroColonne.setBorder(new EmptyBorder(10, 10, 10, 10)); 
		centroColonne.add(colDisponibili); 
		centroColonne.add(colInPrestito); 
		centroColonne.add(colAttesa); 

        // Pannello per lo storico
		JPanel pannelloStorico = new JPanel(new BorderLayout());
		pannelloStorico.setBorder(new EmptyBorder(0, 10, 10, 10));
		pannelloStorico.add(new JLabel("Storico Eventi:"), BorderLayout.NORTH);
		pannelloStorico.add(new JScrollPane(areaStorico), BorderLayout.CENTER);

        // Raggruppo le colonne e lo storico in un unico pannello centrale
		JPanel centroCompleto = new JPanel(new BorderLayout());
		centroCompleto.add(centroColonne, BorderLayout.CENTER); 
		centroCompleto.add(pannelloStorico, BorderLayout.SOUTH);

		// Pannello controlli
		JPanel sud = new JPanel(new BorderLayout());
		sud.setBorder(new EmptyBorder(0, 10, 10, 10));

		JPanel sudInput = new JPanel(new FlowLayout());
		sudInput.add(new JLabel("Utenti (min 5):"));
		sudInput.add(campoUtenti);
		sudInput.add(new JLabel("Prestiti per Utente:"));
		sudInput.add(campoPrestiti);
		sudInput.add(new JLabel("Durata massima prestito:"));
		sudInput.add(campoDurata);

		JPanel sudBottoni = new JPanel(new FlowLayout());
		sudBottoni.add(bAvvia);
		sudBottoni.add(bInterrompi);
		sudBottoni.add(bSalva);
		sudBottoni.add(bCarica);

		sud.add(sudInput, BorderLayout.NORTH);
		sud.add(sudBottoni, BorderLayout.SOUTH);

		setLayout(new BorderLayout());
		add(centroCompleto, BorderLayout.CENTER); 
		add(sud, BorderLayout.SOUTH); 

		// attività bottoni
		bAvvia.addActionListener(e -> avvia());
		bInterrompi.addActionListener(e -> interrompi());
		bSalva.addActionListener(e -> salva());
		bCarica.addActionListener(e -> carica());

		// aggiorna i dati da modificare peche mi smarmella la rotellina per vedere lo storico
		Timer timer = new Timer(300, e -> aggiorna());
		timer.start();

		setMinimumSize(new Dimension(900, 600)); 
		pack();
		setLocationRelativeTo(null);
	}

	private void caricaAllAvvio() {
		// Invariato...
		if (new File(FILE).exists()) {
			try {
				lab = Persistenza.carica(FILE);
				return;
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, "OOOOOOMG Errore lettura" + FILE);
			}
		}
		ArrayList<Strumento> catalogo = new ArrayList<Strumento>();
		catalogo.add(new Strumento("OSC-01", "Oscilloscopio"));
		catalogo.add(new Strumento("MUL-01", "Multimetro"));
		catalogo.add(new Strumento("MUL-02", "Multimetro"));
		catalogo.add(new Strumento("GEN-01", "Generatore"));
		lab = new Laboratorio(catalogo, new ArrayList<String>());
	}

	private void avvia() {
		// Invariato...
		int utenti;
		int prestiti;
		int durata;
		try {
			utenti = Integer.parseInt(campoUtenti.getText());
			prestiti = Integer.parseInt(campoPrestiti.getText());
			durata = Integer.parseInt(campoDurata.getText());
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(this, "Inserire solo numeri interi, grazie!!!!");
			return;
		}
		if ((utenti < 5 || prestiti < 1 || durata < 1) || (utenti > 100 || prestiti > 100 || durata >30000)) {
			JOptionPane.showMessageDialog(this, "Servono almeno : \n - da 5 a 100 utenti,\n - 1 a 100 prestito ,\n - una durata valida, da 1 a 30000ms");
			return;
		}
		ArrayList<String> tipi = lab.tipi();
		threadUtenti.clear();
		for (int i = 1; i <= utenti; i++) {
			Thread t = new Thread(new Utente("Utente" + i, lab, tipi, prestiti, durata));
			threadUtenti.add(t);
			t.start();
		}
		inCorso = true;
		storicoDaAggiornare = true; //ultima modifica
		aggiorna();
	}

	private void interrompi() {
		for (Thread t : threadUtenti) {
			t.interrupt();
		}
	}

	private void salva() {
		try {
			Persistenza.salva(FILE, lab);
			JOptionPane.showMessageDialog(this, "Dati salvati");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Errore salvataggio");
		}
	}

	private void carica() {
		try {
			lab = Persistenza.carica(FILE);
			storicoDaAggiornare = true; //ultima modifica
			aggiorna();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Errore caricamento");
		}
	}

	private void aggiorna() {
		if (inCorso) {
			inCorso = false;
			for (Thread t : threadUtenti) {
				if (t.isAlive()) {
					inCorso = true;
				}
			}
		}
		etDisponibili.setText("Disponibili: " + lab.numeroDisponibili());
		etInPrestito.setText("In prestito: " + lab.numeroInPrestito());
		etInAttesa.setText("In attesa: " + lab.numeroInAttesa());
        
		// Collega ciascuna colonna al rispettivo metodo del Laboratorio:
		areaDisponibili.setText(String.join("\n", lab.descriviDisponibili())); 
		areaInPrestito.setText(String.join("\n", lab.descriviInPrestito()));   
		areaAttese.setText(String.join("\n", lab.richiesteInAttesa()));        

		
		// Aggiorna lo storico SOLO mentre la simulazione è in corso (più un ultimo giro appena finisce/viene interrotta)
		if (inCorso || storicoDaAggiornare) {
		    areaStorico.setText(String.join("\n", lab.copiaStorico()));
		    areaStorico.setCaretPosition(areaStorico.getDocument().getLength());
		    storicoDaAggiornare = inCorso; // Se inCorso è diventato false, al prossimo tick del timer non entrerà più qui
		}
		
		bAvvia.setEnabled(!inCorso);
		bInterrompi.setEnabled(inCorso);
		bCarica.setEnabled(!inCorso);
	}
}

















