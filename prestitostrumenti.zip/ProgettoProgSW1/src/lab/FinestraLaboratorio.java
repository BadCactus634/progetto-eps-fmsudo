
package lab;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public class FinestraLaboratorio extends JFrame {
	private static final String FILE = "laboratorio.txt";

	private Laboratorio lab;
	private ArrayList<Thread> threadUtenti = new ArrayList<Thread>();
	private boolean inCorso = false;
	private boolean storicoDaAggiornare = true; //ultima revisione

	private JLabel etDisponibili = new JLabel("Disponibili: 0");
	private JLabel etInPrestito = new JLabel("In prestito: 0");
	private JLabel etInAttesa = new JLabel("In attesa: 0");
    
    // *** MODIFICA: Ho diviso l'area degli strumenti in due aree distinte ***
	private JTextArea areaDisponibili = new JTextArea(10, 20); // Area per strumenti disponibili
	private JTextArea areaInPrestito = new JTextArea(10, 20); // Area per strumenti/utenti in uso
	private JTextArea areaAttese = new JTextArea(10, 20); // Area per utenti in attesa
	private JTextArea areaStorico = new JTextArea(8, 60); // Area storico ridimensionata per stare in basso

	private JTextField campoUtenti = new JTextField("6", 4);
	private JTextField campoPrestiti = new JTextField("3", 4);
	private JTextField campoDurata = new JTextField("1000", 5);

	private JButton bAvvia = new JButton("Avvia simulazione");
	private JButton bInterrompi = new JButton("Interrompi");
	private JButton bSalva = new JButton("Salva dati");
	private JButton bCarica = new JButton("Carica dati");

	public FinestraLaboratorio() {
		super("Prestito strumenti");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		caricaAllAvvio();

		areaDisponibili.setEditable(false); // Blocca la scrittura all'utente
		areaInPrestito.setEditable(false); // Blocca la scrittura all'utente
		areaAttese.setEditable(false); // Blocca la scrittura all'utente
		areaStorico.setEditable(false);

		
        // Colonna 1: Disponibili (Etichetta + Area testo)
		JPanel colDisponibili = new JPanel(new BorderLayout());
		colDisponibili.add(etDisponibili, BorderLayout.NORTH);
		colDisponibili.add(new JScrollPane(areaDisponibili), BorderLayout.CENTER);

        // Colonna 2: In Prestito (Etichetta + Area testo)
		JPanel colInPrestito = new JPanel(new BorderLayout());
		colInPrestito.add(etInPrestito, BorderLayout.NORTH);
		colInPrestito.add(new JScrollPane(areaInPrestito), BorderLayout.CENTER);

        // Colonna 3: In Attesa (Etichetta + Area testo)
		JPanel colAttesa = new JPanel(new BorderLayout());
		colAttesa.add(etInAttesa, BorderLayout.NORTH);
		colAttesa.add(new JScrollPane(areaAttese), BorderLayout.CENTER);

        // Pannello centrale che raggruppa le 3 colonne usando un GridLayout(1 riga, 3 colonne)
		JPanel centroColonne = new JPanel(new GridLayout(1, 3, 10, 0)); // 10 pixel di spazio orizzontale tra le colonne
		centroColonne.setBorder(new EmptyBorder(10, 10, 10, 10)); // Margine esterno
		centroColonne.add(colDisponibili); // Aggiunge la colonna sinistra
		centroColonne.add(colInPrestito); // Aggiunge la colonna centrale
		centroColonne.add(colAttesa); // Aggiunge la colonna destra

        // Pannello per lo storico (posizionato sotto le 3 colonne)
		JPanel pannelloStorico = new JPanel(new BorderLayout());
		pannelloStorico.setBorder(new EmptyBorder(0, 10, 10, 10));
		pannelloStorico.add(new JLabel("Storico Eventi:"), BorderLayout.NORTH); // Titolo per lo storico
		pannelloStorico.add(new JScrollPane(areaStorico), BorderLayout.CENTER);

        // Raggruppo le colonne e lo storico in un unico pannello centrale
		JPanel centroCompleto = new JPanel(new BorderLayout());
		centroCompleto.add(centroColonne, BorderLayout.CENTER); // Le 3 colonne occupano lo spazio principale
		centroCompleto.add(pannelloStorico, BorderLayout.SOUTH); // Lo storico va in fondo alla parte centrale

		// Pannello controlli (rimane invariato dalla versione precedente con 2 righe per non tagliare)
		JPanel sud = new JPanel(new BorderLayout());
		sud.setBorder(new EmptyBorder(0, 10, 10, 10));

		JPanel sudInput = new JPanel(new FlowLayout());
		sudInput.add(new JLabel("Utenti (min 5):"));
		sudInput.add(campoUtenti);
		sudInput.add(new JLabel("Prestiti per Utente:"));
		sudInput.add(campoPrestiti);
		sudInput.add(new JLabel("Durata massima prestito:"));
		sudInput.add(campoDurata);

		JPanel sudBottoni = new JPanel(new FlowLayout());
		sudBottoni.add(bAvvia);
		sudBottoni.add(bInterrompi);
		sudBottoni.add(bSalva);
		sudBottoni.add(bCarica);

		sud.add(sudInput, BorderLayout.NORTH);
		sud.add(sudBottoni, BorderLayout.SOUTH);

		setLayout(new BorderLayout());
		add(centroCompleto, BorderLayout.CENTER); // Aggiunge tutto il blocco centrale (colonne + storico)
		add(sud, BorderLayout.SOUTH); // Aggiunge i controlli in basso

		// attività bottoni
		bAvvia.addActionListener(e -> avvia());
		bInterrompi.addActionListener(e -> interrompi());
		bSalva.addActionListener(e -> salva());
		bCarica.addActionListener(e -> carica());

		// aggiorna i dati da modificare peche mi smarmella la rotellina per vedere lo storico
		Timer timer = new Timer(300, e -> aggiorna());
		timer.start();

		setMinimumSize(new Dimension(900, 600)); 
		pack();
		setLocationRelativeTo(null);
	}

	private void caricaAllAvvio() {
		// Invariato...
		if (new File(FILE).exists()) {
			try {
				lab = Persistenza.carica(FILE);
				return;
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, "OOOOOOMG Errore lettura" + FILE);
			}
		}
		ArrayList<Strumento> catalogo = new ArrayList<Strumento>();
		catalogo.add(new Strumento("OSC-01", "Oscilloscopio"));
		catalogo.add(new Strumento("MUL-01", "Multimetro"));
		catalogo.add(new Strumento("MUL-02", "Multimetro"));
		catalogo.add(new Strumento("GEN-01", "Generatore"));
		lab = new Laboratorio(catalogo, new ArrayList<String>());
	}

	private void avvia() {
		// Invariato...
		int utenti;
		int prestiti;
		int durata;
		try {
			utenti = Integer.parseInt(campoUtenti.getText());
			prestiti = Integer.parseInt(campoPrestiti.getText());
			durata = Integer.parseInt(campoDurata.getText());
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(this, "Inserire solo numeri interi, grazie!!!!");
			return;
		}
		if ((utenti < 5 || prestiti < 1 || durata < 1) || (utenti > 100 || prestiti > 100 || durata >30000)) {
			JOptionPane.showMessageDialog(this, "Servono almeno : \n - da 5 a 100 utenti,\n - 1 a 100 prestito ,\n - una durata valida, da 1 a 30000ms");
			return;
		}
		ArrayList<String> tipi = lab.tipi();
		threadUtenti.clear();
		for (int i = 1; i <= utenti; i++) {
			Thread t = new Thread(new Utente("Utente" + i, lab, tipi, prestiti, durata));
			threadUtenti.add(t);
			t.start();
		}
		inCorso = true;
		storicoDaAggiornare = true; //ultima modifica
		aggiorna();
	}

	private void interrompi() {
		for (Thread t : threadUtenti) {
			t.interrupt();
		}
	}

	private void salva() {
		try {
			Persistenza.salva(FILE, lab);
			JOptionPane.showMessageDialog(this, "Dati salvati");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Errore salvataggio");
		}
	}

	private void carica() {
		try {
			lab = Persistenza.carica(FILE);
			storicoDaAggiornare = true; //ultima modifica
			aggiorna();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Errore caricamento");
		}
	}

	private void aggiorna() {
		if (inCorso) {
			inCorso = false;
			for (Thread t : threadUtenti) {
				if (t.isAlive()) {
					inCorso = true;
				}
			}
		}
		etDisponibili.setText("Disponibili: " + lab.numeroDisponibili());
		etInPrestito.setText("In prestito: " + lab.numeroInPrestito());
		etInAttesa.setText("In attesa: " + lab.numeroInAttesa());
        
		// Collega ciascuna colonna al rispettivo metodo del Laboratorio:
		areaDisponibili.setText(String.join("\n", lab.descriviDisponibili())); // Colonna 1: solo liberi
		areaInPrestito.setText(String.join("\n", lab.descriviInPrestito()));   // Colonna 2: solo in prestito
		areaAttese.setText(String.join("\n", lab.richiesteInAttesa()));        // Colonna 3: utenti in attesa

		//areaStorico.setText(String.join("\n", lab.copiaStorico()));
		//areaStorico.setCaretPosition(areaStorico.getDocument().getLength());
		// Aggiorna lo storico SOLO mentre la simulazione è in corso (più un ultimo giro appena finisce/viene interrotta)
		if (inCorso || storicoDaAggiornare) {
		    areaStorico.setText(String.join("\n", lab.copiaStorico()));
		    areaStorico.setCaretPosition(areaStorico.getDocument().getLength());
		    storicoDaAggiornare = inCorso; // Se inCorso è diventato false, al prossimo tick del timer non entrerà più qui
		}
		
		bAvvia.setEnabled(!inCorso);
		bInterrompi.setEnabled(inCorso);
		bCarica.setEnabled(!inCorso);
	}
}
















































/*package lab; // Dichiara il pacchetto di appartenenza della classe (deve corrispondere alla cartella)

import java.awt.BorderLayout; // Importa il gestore di layout che divide in Nord, Sud, Est, Ovest, Centro
import java.awt.Dimension; // *** MODIFICA: Importato per gestire la dimensione minima della finestra ***
import java.awt.FlowLayout; // Importa il gestore di layout che dispone gli elementi in riga (uno dopo l'altro)
import java.awt.GridLayout; // Importa il gestore di layout a griglia (righe x colonne)
import java.io.File; // Importa la classe per gestire i file nel sistema operativo
import java.io.IOException; // Importa l'eccezione lanciata in caso di errori di lettura/scrittura file
import java.util.ArrayList; // Importa la struttura dati ArrayList (lista dinamica)

import javax.swing.JButton; // Importa il componente bottone cliccabile dell'interfaccia
import javax.swing.JFrame; // Importa la finestra principale del programma
import javax.swing.JLabel; // Importa il componente per mostrare testo fisso (etichette)
import javax.swing.JOptionPane; // Importa i popup di dialogo (es. messaggi di errore)
import javax.swing.JPanel; // Importa il contenitore generico per raggruppare altri componenti
import javax.swing.JScrollPane; // Importa il pannello con le barre di scorrimento (scroll)
import javax.swing.JTextArea; // Importa l'area di testo multi-riga
import javax.swing.JTextField; // Importa la casella di testo a singola riga (per input utente)
import javax.swing.Timer; // Importa il timer di Swing per eseguire azioni a intervalli regolari
import javax.swing.border.EmptyBorder; // *** MODIFICA: Importato per creare margini vuoti e rendere tutto più carino ***

/**
 * avvia la simulazione e ne mostra l'andamento.
 * I thread degli utenti non toccano la finestra, c'è un Timer Swing che rilegge
 * ogni 300 ms lo stato dal monitor.
 */
/*public class FinestraLaboratorio extends JFrame { // Definisce la classe che eredita da JFrame (è una finestra)
	private static final String FILE = "laboratorio.txt"; // Definisce una costante con il nome del file di salvataggio

	private Laboratorio lab; // Dichiara il riferimento all'oggetto Laboratorio (il monitor/modello dati)
	private ArrayList<Thread> threadUtenti = new ArrayList<Thread>(); // Inizializza la lista che conterrà i thread degli utenti
	private boolean inCorso = false; // Flag booleano per sapere se la simulazione è attualmente in esecuzione

	private JLabel etDisponibili = new JLabel(); // Crea un'etichetta vuota per mostrare gli strumenti disponibili
	private JLabel etInPrestito = new JLabel(); // Crea un'etichetta vuota per mostrare gli strumenti in prestito
	private JLabel etInAttesa = new JLabel(); // Crea un'etichetta vuota per mostrare gli utenti in attesa
	private JTextArea areaStrumenti = new JTextArea(8, 30); // Crea un'area di testo alta 8 righe e larga 30 colonne
	private JTextArea areaAttese = new JTextArea(8, 30); // Crea un'area di testo per le attese (8x30)
	private JTextArea areaStorico = new JTextArea(12, 60); // Crea un'area di testo per lo storico (più grande: 12x60)

	private JTextField campoUtenti = new JTextField("6", 4); // Crea un campo di input con valore di default "6" largo 4 colonne
	private JTextField campoPrestiti = new JTextField("3", 4); // Crea un campo di input con default "3" largo 4 colonne
	private JTextField campoDurata = new JTextField("1000", 5); // Crea un campo di input con default "1000" largo 5 colonne

	private JButton bAvvia = new JButton("Avvia simulazione"); // Crea il bottone per avviare la simulazione
	private JButton bInterrompi = new JButton("Interrompi"); // Crea il bottone per fermare la simulazione
	private JButton bSalva = new JButton("Salva dati"); // Crea il bottone per salvare i dati su file
	private JButton bCarica = new JButton("Carica dati"); // Crea il bottone per caricare i dati da file

	public FinestraLaboratorio() { // Costruttore della classe FinestraLaboratorio
		super("Labo --- Prestito strumenti"); // Chiama il costruttore della superclasse (JFrame) impostando il titolo
		setDefaultCloseOperation(EXIT_ON_CLOSE); // Fa in modo che chiudendo la finestra (X) il programma termini completamente
		caricaAllAvvio(); // Chiama il metodo per caricare i dati (da file o di default) appena si apre l'app

		areaStrumenti.setEditable(false); // Rende l'area degli strumenti in sola lettura (l'utente non può scriverci)
		areaAttese.setEditable(false); // Rende l'area delle attese in sola lettura
		areaStorico.setEditable(false); // Rende l'area dello storico in sola lettura

		JPanel nord = new JPanel(new GridLayout(1, 3)); // Crea un pannello superiore diviso in 1 riga e 3 colonne
		nord.setBorder(new EmptyBorder(10, 10, 10, 10)); // *** MODIFICA: Aggiunge 10 pixel di margine ai lati per estetica ***
		nord.add(etDisponibili); // Aggiunge al pannello nord l'etichetta dei disponibili
		nord.add(etInPrestito); // Aggiunge al pannello nord l'etichetta dei prestiti
		nord.add(etInAttesa); // Aggiunge al pannello nord l'etichetta delle attese

		JPanel centro = new JPanel(new GridLayout(3, 1)); // Crea un pannello centrale diviso in 3 righe e 1 colonna
		centro.setBorder(new EmptyBorder(0, 10, 10, 10)); // *** MODIFICA: Aggiunge margine anche al centro per ordine visivo ***
		centro.add(new JScrollPane(areaStrumenti)); // Inserisce l'area strumenti in uno ScrollPane (barra di scorrimento) e lo aggiunge al centro
		centro.add(new JScrollPane(areaAttese)); // Inserisce l'area attese in uno ScrollPane e lo aggiunge al centro
		centro.add(new JScrollPane(areaStorico)); // Inserisce l'area storico in uno ScrollPane e lo aggiunge al centro

		// pannello controllo
		JPanel sud = new JPanel(new BorderLayout()); // *** MODIFICA: Cambiato da FlowLayout a BorderLayout per gestire due righe distinte ***
		sud.setBorder(new EmptyBorder(0, 10, 10, 10)); // *** MODIFICA: Aggiunto margine inferiore alla finestra ***

		JPanel sudInput = new JPanel(new FlowLayout()); // *** MODIFICA: Creato un sotto-pannello solo per i campi di testo ***
		sudInput.add(new JLabel("Utenti (min 5):")); // Aggiunge l'etichetta descrittiva per gli utenti
		sudInput.add(campoUtenti); // Aggiunge la casella per inserire il numero utenti
		sudInput.add(new JLabel("Prestiti per user:")); // Aggiunge l'etichetta per i prestiti
		sudInput.add(campoPrestiti); // Aggiunge la casella per i prestiti
		sudInput.add(new JLabel("Durata max:")); // Aggiunge l'etichetta per la durata in millisecondi
		sudInput.add(campoDurata); // Aggiunge la casella per inserire la durata

		JPanel sudBottoni = new JPanel(new FlowLayout()); // *** MODIFICA: Creato un sotto-pannello solo per i pulsanti ***
		sudBottoni.add(bAvvia); // Aggiunge il pulsante Avvia al pannello dei bottoni
		sudBottoni.add(bInterrompi); // Aggiunge il pulsante Interrompi al pannello dei bottoni
		sudBottoni.add(bSalva); // Aggiunge il pulsante Salva al pannello dei bottoni
		sudBottoni.add(bCarica); // Aggiunge il pulsante Carica al pannello dei bottoni

		sud.add(sudInput, BorderLayout.NORTH); // *** MODIFICA: Mette i campi di testo nella parte alta del pannello sud ***
		sud.add(sudBottoni, BorderLayout.SOUTH); // *** MODIFICA: Mette i bottoni nella parte bassa del pannello sud (evita che vengano tagliati) ***

		setLayout(new BorderLayout()); // Imposta il layout principale della finestra intera
		add(nord, BorderLayout.NORTH); // Posiziona il pannello nord in alto nella finestra
		add(centro, BorderLayout.CENTER); // Posiziona il pannello centrale (con le aree testo) al centro della finestra
		add(sud, BorderLayout.SOUTH); // Posiziona il pannello sud in basso nella finestra

		// attività bottoni
		bAvvia.addActionListener(e -> avvia()); // Collega il click sul pulsante bAvvia al metodo avvia()
		bInterrompi.addActionListener(e -> interrompi()); // Collega il click sul pulsante bInterrompi al metodo interrompi()
		bSalva.addActionListener(e -> salva()); // Collega il click sul pulsante bSalva al metodo salva()
		bCarica.addActionListener(e -> carica()); // Collega il click sul pulsante bCarica al metodo carica()

		// aggiorna i dati
		Timer timer = new Timer(300, e -> aggiorna()); // Crea un timer che scatta ogni 300 millisecondi chiamando aggiorna()
		timer.start(); // Fa partire il timer

		setMinimumSize(new Dimension(800, 600)); // *** MODIFICA: Imposta una dimensione minima per impedire che gli elementi si schiaccino e si taglino ***
		pack(); // Adatta automaticamente la grandezza della finestra ai componenti contenuti
		setLocationRelativeTo(null); // *** MODIFICA: Apre la finestra esattamente al centro dello schermo (dettaglio estetico) ***
	}

	// se esiste il file lo carica, altrimenti parte da un catalogo di esempio
	private void caricaAllAvvio() { // Definisce il metodo per caricare i dati all'avvio
		if (new File(FILE).exists()) { // Controlla se il file specificato nella costante FILE esiste sul disco
			try { // Inizia il blocco per gestire possibili errori di lettura
				lab = Persistenza.carica(FILE); // Tenta di caricare i dati dal file e li assegna a lab
				return; // Se il caricamento va a buon fine, esce dal metodo
			} catch (IOException e) { // Cattura eventuali errori di I/O (file corrotto, permessi mancanti)
				JOptionPane.showMessageDialog(this, "Errore lettura" + FILE); // Mostra un popup di errore all'utente
			}
		}
		// catalogo
		ArrayList<Strumento> catalogo = new ArrayList<Strumento>(); // Se il file non esiste, crea una nuova lista vuota di strumenti
		catalogo.add(new Strumento("OSC-01", "Oscilloscopio")); // Aggiunge manualmente un Oscilloscopio al catalogo
		catalogo.add(new Strumento("MUL-01", "Multimetro")); // Aggiunge manualmente il primo Multimetro al catalogo
		catalogo.add(new Strumento("MUL-02", "Multimetro")); // Aggiunge manualmente il secondo Multimetro al catalogo
		catalogo.add(new Strumento("GEN-01", "Generatore")); // Aggiunge manualmente un Generatore al catalogo
		lab = new Laboratorio(catalogo, new ArrayList<String>()); // Inizializza il Laboratorio con il catalogo creato e una lista attese vuota
	}

	private void avvia() { // Definisce il metodo per far partire la simulazione
		int utenti; // Dichiara la variabile per il numero di utenti
		int prestiti; // Dichiara la variabile per il numero di prestiti
		int durata; // Dichiara la variabile per la durata
		try { // Inizia il blocco per intercettare conversioni di testo errate
			utenti = Integer.parseInt(campoUtenti.getText()); // Legge il testo dal campoUtenti e lo converte in numero intero
			prestiti = Integer.parseInt(campoPrestiti.getText()); // Legge il testo dal campoPrestiti e lo converte in intero
			durata = Integer.parseInt(campoDurata.getText()); // Legge il testo dal campoDurata e lo converte in intero
		} catch (NumberFormatException e) { // Se l'utente ha inserito lettere al posto di numeri, cattura l'errore
			JOptionPane.showMessageDialog(this, "Inserire solo numeri interi"); // Mostra un messaggio di avviso
			return; // Interrompe il metodo per impedire crash
		}
		if (utenti < 5 || prestiti < 1 || durata < 1) { // Verifica che i dati inseriti rispettino i vincoli logici minimi
			JOptionPane.showMessageDialog(this, "Servono almeno 5 utenti, 1 prestito e una durata valida"); // Avvisa se i dati non vanno bene
			return; // Esce dal metodo
		}
		ArrayList<String> tipi = lab.tipi(); // Recupera la lista dei tipi di strumenti disponibili nel laboratorio
		threadUtenti.clear(); // Svuota la lista dei thread (pulisce precedenti simulazioni)
		for (int i = 1; i <= utenti; i++) { // Avvia un ciclo che parte da 1 fino al numero di utenti scelto
			Thread t = new Thread(new Utente("Utente" + i, lab, tipi, prestiti, durata)); // Crea un nuovo Thread assegnandogli un oggetto Utente
			threadUtenti.add(t); // Aggiunge il thread appena creato alla lista dei thread attivi
			t.start(); // Fa partire l'esecuzione del thread
		}
		inCorso = true; // Segnala che la simulazione è ufficialmente in corso
		aggiorna(); // Chiama il metodo aggiorna() per riflettere subito i cambiamenti a video
	}

	private void interrompi() { // Definisce il metodo per fermare la simulazione manualmente
		for (Thread t : threadUtenti) { // Scorre con un ciclo tutti i thread presenti nella lista
			t.interrupt(); // Invia il segnale di interruzione a ogni singolo thread (lo ferma)
		}
	}

	private void salva() { // Definisce il metodo per salvare lo stato
		try { // Inizia il blocco per intercettare errori di scrittura
			Persistenza.salva(FILE, lab); // Invoca il metodo esterno salva passandogli il nome file e lo stato di lab
			JOptionPane.showMessageDialog(this, "Dati salvati"); // Avvisa l'utente del successo con un popup
		} catch (IOException e) { // Se il salvataggio fallisce (es. disco pieno, permessi) cattura l'errore
			JOptionPane.showMessageDialog(this, "Errore salvataggio"); // Mostra un popup di errore generico
		}
	}

	private void carica() { // Definisce il metodo per forzare il caricamento dei dati
		try { // Blocco di gestione eccezioni
			lab = Persistenza.carica(FILE); // Sovrascrive l'oggetto lab corrente caricandolo dal file
			aggiorna(); // Aggiorna l'interfaccia con i nuovi dati caricati
		} catch (IOException e) { // Se il file non esiste o è illeggibile
			JOptionPane.showMessageDialog(this, "Errore caricamento"); // Mostra un popup di errore
		}
	}

	// rilegge lo stato dal monitor e aggiorna i componenti
	private void aggiorna() { // Metodo vitale chiamato dal timer ogni 300ms per aggiornare l'interfaccia
		if (inCorso) { // Controlla se la simulazione era precedentemente considerata in esecuzione
			inCorso = false; // Abbassa momentaneamente il flag a false
			for (Thread t : threadUtenti) { // Scorre tutti i thread degli utenti
				if (t.isAlive()) { // Se trova anche solo un thread ancora vivo (in esecuzione)
					inCorso = true; // c'e' ancora almeno un thread attivo, quindi riporta inCorso a true
				}
			}
		}
		etDisponibili.setText("Disponibili: " + lab.numeroDisponibili()); // Chiede al lab quanti strumenti ci sono e aggiorna la prima etichetta in alto
		etInPrestito.setText("In prestito: " + lab.numeroInPrestito()); // Chiede al lab i prestiti attivi e aggiorna l'etichetta
		etInAttesa.setText("In attesa: " + lab.numeroInAttesa()); // Chiede al lab quanti utenti aspettano e aggiorna l'etichetta
		areaStrumenti.setText(String.join("\n", lab.descriviStrumenti())); // Unisce la lista descrittiva strumenti andando a capo ad ogni elemento e la stampa
		areaAttese.setText(String.join("\n", lab.richiesteInAttesa())); // Stampa nell'area di testo apposita le richieste in attesa
		areaStorico.setText(String.join("\n", lab.copiaStorico())); // Stampa nell'area in basso lo storico completo
		areaStorico.setCaretPosition(areaStorico.getDocument().getLength()); // Sposta il cursore alla fine dello storico (crea l'effetto autoscroll verso il basso)

		bAvvia.setEnabled(!inCorso); // Accende o spegne il pulsante Avvia (attivo solo se NON c'è una simulazione in corso)
		bInterrompi.setEnabled(inCorso); // Accende o spegne il pulsante Interrompi (attivo solo se C'E' una simulazione)
		bCarica.setEnabled(!inCorso); // Accende o spegne il pulsante Carica (attivo solo a simulazione ferma per evitare conflitti)
	}
}
*/







































































/*package lab;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 * avvia la simulazione e ne mostra l'andamento.
 * I thread degli utenti non toccano la finestra, c'è un Timer Swing che rilegge
 * ogni 300 ms lo stato dal monitor.
 */
/*public class FinestraLaboratorio extends JFrame {
	private static final String FILE = "laboratorio.txt";

	private Laboratorio lab;
	private ArrayList<Thread> threadUtenti = new ArrayList<Thread>();
	private boolean inCorso = false;

	private JLabel etDisponibili = new JLabel();
	private JLabel etInPrestito = new JLabel();
	private JLabel etInAttesa = new JLabel();
	private JTextArea areaStrumenti = new JTextArea(8, 30);
	private JTextArea areaAttese = new JTextArea(8, 30);
	private JTextArea areaStorico = new JTextArea(12, 60);

	private JTextField campoUtenti = new JTextField("6", 4);
	private JTextField campoPrestiti = new JTextField("3", 4);
	private JTextField campoDurata = new JTextField("1000", 5);

	private JButton bAvvia = new JButton("Avvia simulazione");
	private JButton bInterrompi = new JButton("Interrompi");
	private JButton bSalva = new JButton("Salva dati");
	private JButton bCarica = new JButton("Carica dati");

	public FinestraLaboratorio() {
		super("Labo --- Prestito strumenti");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		caricaAllAvvio();

		areaStrumenti.setEditable(false);
		areaAttese.setEditable(false);
		areaStorico.setEditable(false);

		JPanel nord = new JPanel(new GridLayout(1, 3));
		nord.add(etDisponibili);
		nord.add(etInPrestito);
		nord.add(etInAttesa);

		JPanel centro = new JPanel(new GridLayout(3, 1));
		centro.add(new JScrollPane(areaStrumenti)); // Prima area grande
		centro.add(new JScrollPane(areaAttese)); // seconda area grande
		centro.add(new JScrollPane(areaStorico)); // terza area grande (log)

		// pannello controllo
		JPanel sud = new JPanel(new FlowLayout());
		sud.add(new JLabel("Utenti (min 5):"));
		sud.add(campoUtenti);
		sud.add(new JLabel("Prestiti per user:"));
		sud.add(campoPrestiti);
		sud.add(new JLabel("Durata max:")); // in ms, mettere in s?
		
		sud.add(campoDurata);
		sud.add(bAvvia);
		sud.add(bInterrompi);
		sud.add(bSalva);
		sud.add(bCarica);

		setLayout(new BorderLayout());
		add(nord, BorderLayout.NORTH);
		add(centro, BorderLayout.CENTER);
		add(sud, BorderLayout.SOUTH);

		// attività bottoni
		bAvvia.addActionListener(e -> avvia());
		bInterrompi.addActionListener(e -> interrompi());
		bSalva.addActionListener(e -> salva());
		bCarica.addActionListener(e -> carica());

		// aggiorna i dati
		Timer timer = new Timer(300, e -> aggiorna()); // lo scroll non funziona per via dell'aggiornamento
		timer.start();

		pack();
	}

	// se esiste il file lo carica, altrimenti parte da un catalogo di esempio
	private void caricaAllAvvio() {
		if (new File(FILE).exists()) {
			try {
				lab = Persistenza.carica(FILE);
				return;
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, "Errore lettura" + FILE);
			}
		}
		// catalogo
		ArrayList<Strumento> catalogo = new ArrayList<Strumento>();
		catalogo.add(new Strumento("OSC-01", "Oscilloscopio"));
		catalogo.add(new Strumento("MUL-01", "Multimetro"));
		catalogo.add(new Strumento("MUL-02", "Multimetro"));
		catalogo.add(new Strumento("GEN-01", "Generatore"));
		lab = new Laboratorio(catalogo, new ArrayList<String>());
	}

	private void avvia() {
		int utenti;
		int prestiti;
		int durata;
		try {
			utenti = Integer.parseInt(campoUtenti.getText());
			prestiti = Integer.parseInt(campoPrestiti.getText());
			durata = Integer.parseInt(campoDurata.getText());
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(this, "Inserire solo numeri interi");
			return;
		}
		if (utenti < 5 || prestiti < 1 || durata < 1) {
			JOptionPane.showMessageDialog(this, "Servono almeno 5 utenti, 1 prestito e una durata valida");
			return;
		}
		ArrayList<String> tipi = lab.tipi();
		threadUtenti.clear();
		for (int i = 1; i <= utenti; i++) {
			Thread t = new Thread(new Utente("Utente" + i, lab, tipi, prestiti, durata));
			threadUtenti.add(t);
			t.start();
		}
		inCorso = true;
		aggiorna();
	}

	private void interrompi() {
		for (Thread t : threadUtenti) {
			t.interrupt();
		}
	}

	private void salva() {
		try {
			Persistenza.salva(FILE, lab);
			JOptionPane.showMessageDialog(this, "Dati salvati");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Errore salvataggio");
		}
	}

	private void carica() {
		try {
			lab = Persistenza.carica(FILE);
			aggiorna();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Errore caricamento");
		}
	}

	// rilegge lo stato dal monitor e aggiorna i componenti
	private void aggiorna() {
		if (inCorso) {
			inCorso = false;
			for (Thread t : threadUtenti) {
				if (t.isAlive()) {
					inCorso = true; // c'e' ancora almeno un thread attivo
				}
			}
		}
		etDisponibili.setText("Disponibili: " + lab.numeroDisponibili());
		etInPrestito.setText("In prestito: " + lab.numeroInPrestito());
		etInAttesa.setText("In attesa: " + lab.numeroInAttesa());
		areaStrumenti.setText(String.join("\n", lab.descriviStrumenti()));
		areaAttese.setText(String.join("\n", lab.richiesteInAttesa()));
		areaStorico.setText(String.join("\n", lab.copiaStorico()));
		areaStorico.setCaretPosition(areaStorico.getDocument().getLength());

		bAvvia.setEnabled(!inCorso);
		bInterrompi.setEnabled(inCorso);
		bCarica.setEnabled(!inCorso);
	}
}*/
